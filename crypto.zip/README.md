Запуск проекта через докер. Команда make init

Конфиг файл в config/cryptogram

Доменная область в app/Cards
