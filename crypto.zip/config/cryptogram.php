<?php

return [
    'ttl_interval' => '3600',
    'public_key' => 'cryptogram/public_key',
    'private_key' => 'cryptogram/private_key'
];
